from flask import Flask, redirect, request, session, render_template
import requests
import config

app = Flask(__name__)
app.secret_key = '@ugusT0ostuo'

DISCORD_API = "https://discord.com/api"

@app.route('/')
def home():
    if 'user' in session:
        user = session['user']
        if user['id'] not in config.AUTHORIZED_USERS:
            return "Acesso negado. Você não é um moderador autorizado.", 403
        return render_template("panel.html", username=user['username'])
    return redirect("/login")

@app.route('/login')
def login():
    return redirect(
        f"{DISCORD_API}/oauth2/authorize?client_id={config.CLIENT_ID}&redirect_uri={config.REDIRECT_URI}&response_type=code&scope=identify"
    )

@app.route('/callback')
def callback():
    code = request.args.get("code")
    data = {
        "client_id": config.CLIENT_ID,
        "client_secret": config.CLIENT_SECRET,
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": config.REDIRECT_URI,
        "scope": "identify"
    }
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    response = requests.post(f"{DISCORD_API}/oauth2/token", data=data, headers=headers)
    access_token = response.json()['access_token']
    user_response = requests.get(f"{DISCORD_API}/users/@me", headers={"Authorization": f"Bearer {access_token}"})
    session['user'] = user_response.json()
    return redirect("/")

@app.route('/ban', methods=['POST'])
def ban():
    if 'user' not in session or session['user']['id'] not in config.AUTHORIZED_USERS:
        return "Não autorizado", 403

    data = request.form
    player = data.get("player")
    motivo = data.get("motivo")
    tempo = data.get("tempo")
    moderador = session['user']['username']

    embed = {
        "username": "Sistema de Banimento",
        "embeds": [{
            "title": "[VOCÊ FOI BANIDO]",
            "description": f"Pelo motivo... **{motivo}**\nQual moderador te baniu... **{moderador}**\nQuanto tempo... **{tempo}**\n\nSempre obedeça às regras da roblox e do jogo para que todos possam se divertir.\n**Projeto Forge ┃ Contra o uso de trapaças**",
            "color": 15158332,
        }]
    }

    requests.post(config.WEBHOOK_URL, json=embed)
    return f"{player} foi banido com sucesso."

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect('/')